// main.js
mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));