// ============================================
// db.js - Koneksi Database Supabase
// ============================================

// ===== KONFIGURASI SUPABASE =====
// ✅ Menggunakan credentials dari project Anda
const SUPABASE_URL = 'https://qdxclryezrtpflxsuumj.supabase.co';
const SUPABASE_KEY = 'sb_publishable_snmipyvMXk3LSv5niIVtJA_G617eNnb';

// ============================================
// FUNGSI FETCH DENGAN HANDLER ERROR
// ============================================
async function supabaseFetch(endpoint, options = {}) {
    const url = `${SUPABASE_URL}/rest/v1/${endpoint}`;
    
    const defaultHeaders = {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`
    };

    try {
        const response = await fetch(url, {
            ...options,
            headers: { ...defaultHeaders, ...options.headers }
        });

        if (!response.ok) {
            const error = await response.json();
            console.error('❌ Response Error:', error);
            throw new Error(error.message || 'Database error');
        }

        return await response.json();
    } catch (error) {
        console.error('❌ Database Error:', error);
        throw error;
    }
}

// ============================================
// CRUD FUNCTIONS - KARYAWAN
// ============================================
async function getKaryawan() {
    try {
        const data = await supabaseFetch('karyawan?order=join_date.asc');
        console.log(`✅ Loaded ${data.length} karyawan from database`);
        return data;
    } catch (error) {
        console.error('Error loading karyawan:', error);
        return [];
    }
}

async function saveKaryawan(data) {
    try {
        // Cek apakah data sudah ada
        const existing = await supabaseFetch(`karyawan?id=eq.${data.id}`);
        
        if (existing && existing.length > 0) {
            // Update
            await supabaseFetch(`karyawan?id=eq.${data.id}`, {
                method: 'PATCH',
                body: JSON.stringify(data)
            });
            console.log(`✅ Updated karyawan: ${data.id}`);
        } else {
            // Insert
            await supabaseFetch('karyawan', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            console.log(`✅ Inserted karyawan: ${data.id}`);
        }
        return true;
    } catch (error) {
        console.error('Error saving karyawan:', error);
        return false;
    }
}

async function deleteKaryawan(id) {
    try {
        await supabaseFetch(`karyawan?id=eq.${id}`, {
            method: 'DELETE'
        });
        console.log(`✅ Deleted karyawan: ${id}`);
        return true;
    } catch (error) {
        console.error('Error deleting karyawan:', error);
        return false;
    }
}

// ============================================
// CRUD FUNCTIONS - IZIN
// ============================================
async function getIzin() {
    try {
        const data = await supabaseFetch('izin?order=date.desc,created_at.desc');
        console.log(`✅ Loaded ${data.length} izin from database`);
        return data;
    } catch (error) {
        console.error('Error loading izin:', error);
        return [];
    }
}

async function saveIzin(data) {
    try {
        // Cek apakah data sudah ada
        const existing = await supabaseFetch(
            `izin?date=eq.${data.date}&name=eq.${data.name}&jam_izin=eq.${data.jam_izin}`
        );
        
        if (existing && existing.length > 0) {
            // Update
            const id = existing[0].id;
            await supabaseFetch(`izin?id=eq.${id}`, {
                method: 'PATCH',
                body: JSON.stringify(data)
            });
            console.log(`✅ Updated izin: ${data.name} - ${data.date}`);
        } else {
            // Insert
            await supabaseFetch('izin', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            console.log(`✅ Inserted izin: ${data.name} - ${data.date}`);
        }
        return true;
    } catch (error) {
        console.error('Error saving izin:', error);
        return false;
    }
}

// ============================================
// CRUD FUNCTIONS - USERS
// ============================================
async function getUsers() {
    try {
        const data = await supabaseFetch('users');
        console.log(`✅ Loaded ${data.length} users from database`);
        return data;
    } catch (error) {
        console.error('Error loading users:', error);
        return [];
    }
}

async function saveUser(data) {
    try {
        const existing = await supabaseFetch(`users?id=eq.${data.id}`);
        
        if (existing && existing.length > 0) {
            await supabaseFetch(`users?id=eq.${data.id}`, {
                method: 'PATCH',
                body: JSON.stringify(data)
            });
            console.log(`✅ Updated user: ${data.email}`);
        } else {
            await supabaseFetch('users', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            console.log(`✅ Inserted user: ${data.email}`);
        }
        return true;
    } catch (error) {
        console.error('Error saving user:', error);
        return false;
    }
}

// ============================================
// CRUD FUNCTIONS - ROLES
// ============================================
async function getRoles() {
    try {
        const data = await supabaseFetch('roles');
        console.log(`✅ Loaded ${data.length} roles from database`);
        return data;
    } catch (error) {
        console.error('Error loading roles:', error);
        return [];
    }
}

async function saveRole(data) {
    try {
        const existing = await supabaseFetch(`roles?id=eq.${data.id}`);
        
        if (existing && existing.length > 0) {
            await supabaseFetch(`roles?id=eq.${data.id}`, {
                method: 'PATCH',
                body: JSON.stringify(data)
            });
            console.log(`✅ Updated role: ${data.role_name}`);
        } else {
            await supabaseFetch('roles', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            console.log(`✅ Inserted role: ${data.role_name}`);
        }
        return true;
    } catch (error) {
        console.error('Error saving role:', error);
        return false;
    }
}

// ============================================
// CRUD FUNCTIONS - SETTINGS
// ============================================
async function getSettings() {
    try {
        const data = await supabaseFetch('settings');
        const settings = {};
        data.forEach(item => {
            settings[item.key] = item.value;
        });
        console.log('✅ Loaded settings from database');
        return settings;
    } catch (error) {
        console.error('Error loading settings:', error);
        return {};
    }
}

async function saveSetting(key, value) {
    try {
        const existing = await supabaseFetch(`settings?key=eq.${key}`);
        
        if (existing && existing.length > 0) {
            await supabaseFetch(`settings?key=eq.${key}`, {
                method: 'PATCH',
                body: JSON.stringify({ value })
            });
        } else {
            await supabaseFetch('settings', {
                method: 'POST',
                body: JSON.stringify({ key, value })
            });
        }
        console.log(`✅ Saved setting: ${key}`);
        return true;
    } catch (error) {
        console.error('Error saving setting:', error);
        return false;
    }
}

// ============================================
// CRUD FUNCTIONS - AUDIT LOG
// ============================================
async function getAuditLog() {
    try {
        const data = await supabaseFetch('audit_log?order=timestamp.desc&limit=500');
        console.log(`✅ Loaded ${data.length} audit logs from database`);
        return data;
    } catch (error) {
        console.error('Error loading audit log:', error);
        return [];
    }
}

async function saveAuditLog(data) {
    try {
        const payload = {
            username: data.user || data.username || 'System',
            action: data.action,
            details: data.details || '-',
            ip: data.ip || '127.0.0.1'
        };
        
        await supabaseFetch('audit_log', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        console.log(`✅ Saved audit log: ${data.action}`);
        return true;
    } catch (error) {
        console.error('Error saving audit log:', error);
        return false;
    }
}

// ============================================
// EXPORT FUNCTIONS
// ============================================
window.db = {
    // Karyawan
    getKaryawan,
    saveKaryawan,
    deleteKaryawan,
    
    // Izin
    getIzin,
    saveIzin,
    
    // Users
    getUsers,
    saveUser,
    
    // Roles
    getRoles,
    saveRole,
    
    // Settings
    getSettings,
    saveSetting,
    
    // Audit Log
    getAuditLog,
    saveAuditLog,
    
    // Config
    SUPABASE_URL,
    SUPABASE_KEY
};

console.log('🗄️ Database module loaded successfully!');
console.log(`📡 Connected to: ${SUPABASE_URL}`);
console.log(`🔑 Using API Key: ${SUPABASE_KEY.substring(0, 20)}...`);